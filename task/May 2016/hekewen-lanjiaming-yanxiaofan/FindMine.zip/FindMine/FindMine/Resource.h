//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FindMine.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FindMineTYPE                129

#define IDB_BTNDOWN                     135
#define IDB_BTNUP                       136
#define IDB_BTNMARK                     137
#define IDB_BTNMINE                     138

#define ID_BTN_START                    32772
#define ID_APP_START                    32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
