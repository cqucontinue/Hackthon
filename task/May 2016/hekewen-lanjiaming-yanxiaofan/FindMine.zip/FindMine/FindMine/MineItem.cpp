#include "StdAfx.h"
#include "MineItem.h"


MineItem::MineItem(  )
{
     _isMine = false;
	 _isOpen = false;
	 _isMark = false;
	 _Neighbour = 0;
}

MineItem::~MineItem(void)
{
}


